import {Component, OnInit} from '@angular/core';

declare var $;

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {

   Menus = [
    {"id":"D1","name":"Dashboard vvv1"},
    {"id":"D2","name":"Dashboard vvv2"},
    {"id":"D3","name":"Pivot"}
    
];


  constructor() {
  }

  ngOnInit() {
    $(document).ready(() => {
      $('.sidebar-menu').tree();
    });
  }

}
