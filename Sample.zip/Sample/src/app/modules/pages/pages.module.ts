import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import { DragDropModule } from '@angular/cdk/drag-drop';
import {PagesRoutingModule} from './pages-routing.module';
import {PagesComponent} from './pages/pages.component';
import {DashBoardComponent} from './dash-board/dash-board.component';
import {LayoutModule} from '../layout/layout.module';
import { Dashboard2LayoutModule } from './dash-board2/dashboard2Header/dashboard2Header.module';
import { PivotComponent } from './Pivot/Pivot.component';



@NgModule({
  declarations: [PagesComponent, DashBoardComponent,PivotComponent],
  imports: [
    CommonModule,
    PagesRoutingModule,
    DragDropModule,
    LayoutModule,
    Dashboard2LayoutModule
  ]
})
export class PagesModule {
}
