import {Component, OnInit} from '@angular/core';

@Component({
 
  templateUrl: './dash-board2.component.html',
  styleUrls: ['./dash-board2.component.scss']
})
export class DashBoard2Component implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
