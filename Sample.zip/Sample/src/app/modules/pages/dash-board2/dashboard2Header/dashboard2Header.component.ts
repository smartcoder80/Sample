import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-dashHeader',
  templateUrl: './dashboard2Header.component.html',
  styleUrls: ['./dashboard2Header.component.scss']
})
export class DashBoard2HeaderComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
