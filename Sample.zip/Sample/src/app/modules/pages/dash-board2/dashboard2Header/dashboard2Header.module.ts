import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import { RouterModule } from '@angular/router';
import { DashBoard2HeaderComponent } from './dashboard2Header.component';
import { DashBoard2Component } from '../dash-board2.component';


@NgModule({
  declarations: [DashBoard2Component,
    DashBoard2HeaderComponent],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [
    DashBoard2HeaderComponent
  ]
})
export class Dashboard2LayoutModule {
}
