export interface Todo {
    title: string;
    dateAdded: string;
  }