import {Component, OnInit} from '@angular/core';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';
import { Todo } from './todo';
@Component({
  templateUrl: './Pivot.component.html',
  styleUrls: ['./Pivot.component.css']
})
  export class PivotComponent implements OnInit {
    data = [
      "apple",
      "boy",
      "cat",
      "dog",
      "elephant"
    ];
    FilterData=[];
    ColumnData=[];
    RowData=[];
    ValueData=[];
    Filterdrop(event) {
      this.FilterData.push(event.item.data);
    }
    Columndrop(event) {
      this.ColumnData.push(event.item.data);
    }
    Rowdrop(event) {
      this.RowData.push(event.item.data);
    }
    Valuedrop(event) {
      this.ValueData.push(event.item.data);
    }
    
  
    constructor() { }
  
    ngOnInit() {
    }
  
  }