import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {PagesComponent} from './pages/pages.component';
import {DashBoardComponent} from './dash-board/dash-board.component';
import { DashBoard2Component } from './dash-board2/dash-board2.component';
import { Dashboard2LayoutModule } from './dash-board2/dashboard2Header/dashboard2Header.module';
import { PivotComponent } from './Pivot/Pivot.component';

var menudetails =  [
  {path: '', component: DashBoardComponent},
  {path: 'D1', component: DashBoardComponent},
  {path: 'D2',component: DashBoard2Component},
  {path: 'D3',component: PivotComponent}
]


const routes: Routes = [
  {
    path: '', component: PagesComponent, children: menudetails
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes),Dashboard2LayoutModule],
  exports: [RouterModule]
})
export class PagesRoutingModule {
}
