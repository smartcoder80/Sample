import {Component, OnInit} from '@angular/core';

@Component({
 
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.scss']
})
export class DashBoardComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
